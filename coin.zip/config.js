/**
 * API 설정 파일
 * 실제 배포 시에는 이 파일을 .gitignore에 추가하거나
 * 환경변수를 사용하는 것을 권장합니다.
 */

// 개발용 설정
const config = {
    development: {
        // 공개 API만 사용하므로 API 키 불필요
        BASE_URL: 'https://api.binance.com/api/v3'
    },
    production: {
        // 공개 API만 사용하므로 API 키 불필요
        BASE_URL: 'https://api.binance.com/api/v3'
    }
};

// 현재 환경 설정 (개발/프로덕션)
const currentEnv = process.env.NODE_ENV || 'development';

// 설정 내보내기
if (typeof module !== 'undefined' && module.exports) {
    module.exports = config[currentEnv];
} else {
    // 브라우저 환경에서 사용할 경우
    window.API_CONFIG = config[currentEnv];
} 